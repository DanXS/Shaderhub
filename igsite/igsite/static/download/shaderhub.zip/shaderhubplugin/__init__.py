bl_info = {
	"name": "Shaderhub Uploader",
	"author": "Dan Shepherd",
	"version": (1, 0),
	"blender": (2, 6, 9),
	"location": "",
	"description": "Upload 3D content to Shader Hub",
	"warning": "Script requires requests module",
	"wiki_url": "http://shaderhub.com",
	"tracker_url": "",
	"category": "ShaderHub"}

from .dependency_util import checkDependencies
import requests
import bpy
from bpy.types	import	Panel, Operator
from bpy.props	import	StringProperty, EnumProperty

class SCENE_PT_shaderhub(Panel):
    """Upload 3D to Shaderhub"""
    bl_name         = "SCENE_PT_shaderhub"
    bl_label		= "Shaderhub"
    bl_description	= "Upload your 3D content to shaderhub.com"
    bl_space_type   = 'PROPERTIES'
    bl_region_type  = 'WINDOW'
    bl_context      = "scene"

    bpy.types.Scene.sh_host = StringProperty(
        name="URL",
        default="http://igsite-shaderdesigner.rhcloud.com/datastore/uploadjson")

    bpy.types.Scene.sh_file = StringProperty(
        name="File",
        default="",
        description="Enter a filename here")

    bpy.types.Scene.sh_description = StringProperty(
        name="Description",
        default="",
        description="Enter a description of your file here")
 
    bpy.types.Scene.sh_secret = StringProperty(
        name="Secret",
        description="Enter secret GUID here")

    bpy.types.Scene.sh_mode = EnumProperty(
        name="Upload Mode",
        items=[("overwrite","Overwrite","","", 1), ("merge","Merge","","", 2)]
        )

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        row = layout.row()
        row.prop(scene, "sh_host")
        row = layout.row()
        row.prop(scene, "sh_file")
        row = layout.row()
        row.prop(scene, "sh_description")
        row = layout.row()
        row.prop(scene, "sh_secret")
        row = layout.row()
        row.prop(scene, "sh_mode")
        row = layout.row()
        row.operator("upload.button", text="upload")

class OBJECT_OT_Button(Operator):
    bl_idname = "upload.button"
    bl_label = "Upload"
    def execute(self, context):
        scene = context.scene
        if not checkDependencies(['requests', 'json']):
            self.report({'ERROR'}, "Shaderhub requires that 'requests' and 'json' modules are installed")
        elif getattr(scene, "sh_host") == '' or \
                getattr(scene, "sh_file") == '' or \
                getattr(scene, "sh_description") == '' or \
                getattr(scene, "sh_secret") == '':
            self.report({'ERROR'}, "Please ensure all fields are filled in")
        else:
            from .post_json import doPost
            url = getattr(scene, "sh_host")
            scene_file = {
                'file_name' : getattr(scene, "sh_file"),
                'file_info' : getattr(scene, "sh_description"),
                'secret' : getattr(scene, "sh_secret"),
                'op' : getattr(scene, "sh_mode")}
            doPost(bpy.context, bpy.ops, scene_file, url)
            self.report({'INFO'}, "Object(s) uploaded successfully to "+getattr(scene, "sh_host"))
        return {'FINISHED'}


def register():
    bpy.utils.register_class(SCENE_PT_shaderhub)
    bpy.utils.register_class(OBJECT_OT_Button)

def unregister():
	bpy.utils.unregister_class(SCENE_PT_shaderhub)
	bpy.utils.unregister_class(OBJECT_OT_Button)

if __name__ == "__main__":
	register()

