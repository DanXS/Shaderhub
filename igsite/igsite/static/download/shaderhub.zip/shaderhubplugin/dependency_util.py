import sys

def moduleExists(module_name):
    if module_name in sys.modules.keys():
        return True
    else:
        return False

def checkDependencies(dependencies):
    success = True
    for module_name in dependencies:
        if not moduleExists(module_name):
            print("Missing Module Dependency: " + module_name)
            success = False
    return success



